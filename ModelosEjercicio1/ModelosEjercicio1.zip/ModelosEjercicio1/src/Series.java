
public interface Series {
	int getSiguiente(); // Retorna el siguiente número de la serie

	void reiniciar(); // Reinicia

	void setComenzar(int x); // Establece un valor inicial
}
