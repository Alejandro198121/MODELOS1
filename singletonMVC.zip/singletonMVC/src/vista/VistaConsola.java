package vista;

public class VistaConsola {

}
