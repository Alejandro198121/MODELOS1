package controlador;

import modelo.EdificioUnico;

public class AplMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EdificioUnico obj = EdificioUnico.getInstancia();
		EdificioUnico otro = EdificioUnico.getInstancia();
		
		obj.setPruebaInstancia("UNIVERSIDAD DISTRITAL");
		System.out.println(otro.getPruebaInstancia());
		
	}

}
