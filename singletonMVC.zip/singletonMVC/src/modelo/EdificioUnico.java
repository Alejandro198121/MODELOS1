package modelo;

public class EdificioUnico {

	private static EdificioUnico instancia = null;
	private String pruebaInstancia = null;

	private EdificioUnico() {
	}

	public static EdificioUnico getInstancia() {
		if (instancia == null) {
			instancia = new EdificioUnico();
		}
		return instancia;
	}

	public void direccion(String direction) {
		System.out.println(direction);
	}

	public void setPruebaInstancia(String salida) {
		pruebaInstancia = salida;
	}

	public String getPruebaInstancia() {
		return pruebaInstancia;
	}

}
