package model;

/*
 * Desarrollarán un sistema para crear copias de personajes en un videojuego. Cada personaje tiene
atributos como nombre, puntos de vida, habilidades y nivel. Usarás el patrón Prototype para
permitir la clonación rápida de personajes a partir de un personaje base.

 * */
public class Personaje {

	String nombre;
	int puntosDeVida;
	String habilidades;
	int nivel;

	public Personaje(String nombre, int puntosDeVida, String habilidades, int nivel) {
		super();
		this.nombre = nombre;
		this.puntosDeVida = puntosDeVida;
		this.habilidades = habilidades;
		this.nivel = nivel;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPuntosDeVida() {
		return puntosDeVida;
	}

	public void setPuntosDeVida(int puntosDeVida) {
		this.puntosDeVida = puntosDeVida;
	}

	public String getHabilidades() {
		return habilidades;
	}

	public void setHabilidades(String habilidades) {
		this.habilidades = habilidades;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

}
