package controller;

public interface Prototipo {

}
