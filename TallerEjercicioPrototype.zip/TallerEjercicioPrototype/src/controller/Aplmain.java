package controller;

public class Aplmain {

	public static void main(String[] args) {

		Controlador control;
		control = new Controlador();
		control.run();

	}
}