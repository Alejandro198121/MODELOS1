package controller;


import model.Personaje;
import view.Vista;

public class Controlador {
	private Vista vista;

	public Controlador() {
		vista = new Vista();
	}
	
	public void run() {
		boolean opcionValida = false;
		int opcion = 0;
		
		while (!opcionValida) {
			vista.mostrarInformacion("Sistema de creacion de personaje de videojuego");
			opcion = vista.leerDatoEntero("menu:"
					+ "\n 1.) opcion 1"
					+ "\n 2.) opcion 2"
					+ "\n 3.) salir.");

			switch (opcion) {
			case 1:
				vista.mostrarInformacion("..........personaje creado..........");
				opcionValida = true;
				break;
			case 2:
				vista.mostrarInformacion("..........personaje creado2..........");
				opcionValida = true;
				break;
			case 3:
				vista.mostrarInformacion("..........saliendo..........");
				opcionValida = false;
				break;
			default:
				System.out.println("Opción no válida, por favor intenta de nuevo.");
				break;
			}
		}
		
		
		Personaje per1= new Personaje("luis", 100, "lanzar rayo", 1);
		vista.mostrarInformacion("El nombre es ...." + per1.getNombre());

		Personaje per2= new Personaje("Tomas", 100, "curación", 2);

		per2 = per1;
		vista.mostrarInformacion("El nombre es en el objeto dos...." + per2.getNombre());

		// se cambia el nombre en el objeto dos

		per1.setNombre("Carlos Fernando");
		vista.mostrarInformacion("El nombre es ...." + per1.getNombre());
		vista.mostrarInformacion("El nombre es en el objeto dos modificado...." + per2.getNombre());
	}
}
