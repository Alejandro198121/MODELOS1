package view;

import java.util.Scanner;

public class Vista {

	private Scanner sc;

	public Vista() {
		sc = new Scanner(System.in);
	}

	public void mostrarInformacion(String mensaje) {
		System.out.println(mensaje);
	}

	public int leerDatoEntero(String mensaje) {
		int dato = 0;
		System.out.print(mensaje);
		dato = sc.nextInt();
		return dato;
	}

	public String leerString(String mensaje) {
		String texto;
		System.out.println(mensaje);
		texto = sc.next();
		return texto;
	}

}
